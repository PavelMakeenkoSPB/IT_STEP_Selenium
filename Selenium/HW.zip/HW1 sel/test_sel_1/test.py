from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait


s=Service('C:\selenium\test_sel_1\chromedriver.exe')
driver=webdriver.Chrome(service=s)
driver.maximize_window()
driver.get('https://www.google.com')
driver.find_element(By.NAME, 'q').send_keys('Yasser Khalil', Keys.RETURN)
driver.find_element(By.NAME, 'btnK').click()
driver.find_element(By.CSS_SELECTOR, "#.search3__button")
WebDriverWait(context.browser, 120).until(
        EC.presence_of_element_located(By.XPATH, '//*[contains(text(), "%s")]' % text))


